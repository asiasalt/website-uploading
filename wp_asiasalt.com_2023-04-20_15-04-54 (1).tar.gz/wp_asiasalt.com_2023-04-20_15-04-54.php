<?php exit();?>
{
    "name": "wp_asiasalt.com_2023-04-20_15-04-54",
    "backup_dir": 0,
    "backup_db": "1",
    "email": "admin@asiasalt.com",
    "date_time": "2023-04-20 15:04:pm",
    "btime": 1682003094,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "https:\/\/asiasalt.com\/wp",
    "backup_site_path": "\/home\/asiasalt\/domains\/asiasalt.com\/public_html\/wp"
}